package com.example.test;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestApplication { // https://www.devglan.com/spring-security/spring-boot-security-oauth2-example

	// OAuth is a secure authorization protocol that deals with the authorization of third party application
		// to access the user data (login with FB, Google)
		// enables applications to obtain limited access to user accounts on an HTTP service
	// OAuth Provider = provides auth token such as FB, Google
	// OAuth Client = the application that require access credentials of the owner
	// OAuth Owner = the user that has an account on the provider (FB, Google)

	// 0. resource server (data that the app needs) delegates auth responsibility to auth server (FB, Google)
	// 1. resource owner (user) uses the app
	// 2. app needs credentials to access something, so user authenticates to the auth server
	// 3. auth server sends a generated token to the app (client)
	// 4. the app uses this to access the protected resources on the resource server

	public static void main(String[] args) {
		SpringApplication.run(TestApplication.class, args);
	}

}
