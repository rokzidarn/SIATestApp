package com.example.test.service;

import com.example.test.model.User;

import java.util.List;

public interface UserInterface {

    User save(User user);
    List<User> findAll();
    void delete(User user);
    User get(String userId);
}