package com.example.test.controller;

import com.example.test.model.User;
import com.example.test.service.UserInterface;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/users")
public class UserController {

    @Autowired
    private UserInterface userInterface;

    @RequestMapping(value="/all", method = RequestMethod.GET)
    public List<User> listUser(){
        return userInterface.findAll();
    }
}
