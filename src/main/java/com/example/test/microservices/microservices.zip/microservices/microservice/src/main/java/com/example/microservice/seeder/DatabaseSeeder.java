package com.example.microservice.seeder;

import com.example.microservice.model.Item;
import com.example.microservice.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.event.ContextRefreshedEvent;
import org.springframework.context.event.EventListener;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;

@Component
public class DatabaseSeeder {

    private ItemRepository itemRepository;
    private JdbcTemplate jdbcTemplate;

    @Autowired
    public DatabaseSeeder(ItemRepository itemRepository, JdbcTemplate jdbcTemplate) {
        this.itemRepository = itemRepository;
        this.jdbcTemplate = jdbcTemplate;
    }

    @EventListener
    public void seed(ContextRefreshedEvent event) {
        Item i1 = new Item();
        i1.setName("Nike Foamposite X1");
        i1.setPrice(120);
        i1.setCreated(new Date());
        i1.setCategory("Basketball");
        itemRepository.save(i1);

        Item i2 = new Item();
        i2.setName("Nike Vomero 12");
        i2.setPrice(90);
        i2.setCreated(new Date());
        i2.setCategory("Running");
        itemRepository.save(i2);

        Item i3 = new Item();
        i3.setName("Nike Air Jordan III");
        i3.setPrice(105);
        i3.setCreated(new Date());
        i3.setCategory("Basketball");
        itemRepository.save(i3);
    }
}