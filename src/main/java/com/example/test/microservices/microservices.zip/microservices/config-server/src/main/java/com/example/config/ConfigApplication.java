package com.example.config;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@EnableConfigServer
@SpringBootApplication
public class ConfigApplication {

	// config server is used to centralize/share configuration among multiple instances of several services
	// one advantage there is it separates configuration from the code (dev/ops), can also be encrypted
	// first is config server, then service discovery
	// localhost:8888/application/default
	// application == spring.application.name, default == active Spring profile

	public static void main(String[] args) {
		SpringApplication.run(ConfigApplication.class, args);
	}

}
