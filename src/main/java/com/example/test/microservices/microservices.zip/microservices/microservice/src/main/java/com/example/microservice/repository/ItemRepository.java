package com.example.microservice.repository;

import com.example.microservice.model.Item;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository("itemRepository")
public interface ItemRepository extends JpaRepository<Item, Integer> {
    List<Item> findAll();
    Optional<Item> findById(Integer integer);
    List<Item> findByCategory(String category);
}
