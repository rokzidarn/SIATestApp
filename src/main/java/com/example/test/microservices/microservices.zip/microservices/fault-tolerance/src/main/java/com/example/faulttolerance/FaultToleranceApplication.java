package com.example.faulttolerance;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.dashboard.EnableHystrixDashboard;

@SpringBootApplication
@EnableHystrixDashboard
public class FaultToleranceApplication {

	// Hystrix fault tolerance, if a service fails, returns a generic/default response
	// allows resiliency, circuit breaker/timeout can avoid failing (latency) but also try again if service has been restored

	public static void main(String[] args) {
		SpringApplication.run(FaultToleranceApplication.class, args);
	}

}
