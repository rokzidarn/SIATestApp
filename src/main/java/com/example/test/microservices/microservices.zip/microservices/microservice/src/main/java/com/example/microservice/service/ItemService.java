package com.example.microservice.service;

import com.example.microservice.model.Item;
import com.example.microservice.repository.ItemRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service("itemService")
public class ItemService {

    private ItemRepository itemRepository;

    @Autowired
    public ItemService(ItemRepository itemRepository) {
        this.itemRepository = itemRepository;
    }

    public List<Item> findAllItems() {
        return itemRepository.findAll();
    }
    public Optional<Item> findItemById(int id) {
        return itemRepository.findById(id);
    }
    public List<Item> findItemByCategory(String category) {
        return itemRepository.findByCategory(category);
    }
    public Item saveItem(Item item) {
        return itemRepository.save(item);
    }
    public Item updateItem(Item item) {
        return itemRepository.save(item);
    }
    public void deleteItemById(int id) {
        itemRepository.deleteById(id);
    }
}