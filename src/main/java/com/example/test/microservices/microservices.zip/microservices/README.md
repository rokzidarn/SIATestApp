# SIATestAppMicro

My basic web application developed using Java and Spring with microservices.

### Techstack
```
Java Spring Microservices
Actuator (health, logging, metrics)
Eureka
Hystrix
```

### Requirements (in order)
+ run config-server
+ run service-discovery
+ run microservice
+ run fault-tolerance