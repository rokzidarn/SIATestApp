package com.example.microservice.health;

import org.springframework.boot.actuate.health.Health;
import org.springframework.boot.actuate.health.HealthIndicator;
import org.springframework.stereotype.Component;

@Component
public class CustomHealth implements HealthIndicator {

    @Override
    public Health health() {
        if (Math.random() < 0.1) {
            return Health.down()
                    .withDetail("reason", "I break 10% of the time").build();
        }
        return Health.up()
                .withDetail("reason", "All is good!").build();
    }
}