package com.example.microservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.hystrix.EnableHystrix;

@SpringBootApplication
@EnableHystrix
public class MicroserviceApplication {

	// Eureka service discovery, some service registers here, then when another service needs data from the first one
		// calls Eureka which provides it with information where that data/service is available
		// there can also be a load balancer (Ribbon) which decides which instance of the needed service is called

	public static void main(String[] args) {
		SpringApplication.run(MicroserviceApplication.class, args);
	}

	// consuming data from other services is done by a load balanced rest template
	// @LoadBalanced RestTemplate restTemplate;
	// restTemplate.getForObject("http://item-service/items/{id}", Item.class, itemId);

	// config server, centralized configuration, allows encryption, on the fly changes

	// Hystrix fault tolerance, if a service fails, returns a generic/default response
	// allows resiliency, circuit breaker/timeout can avoid failing (latency) but also try again if service has been restored

	// Actuator has health, logging and metrics

	// TODO: add Dockerfile

}
