package com.example.microservice.controller;

import com.example.microservice.model.Greeting;
import com.example.microservice.model.Item;
import com.example.microservice.service.ItemService;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixCommand;
import com.netflix.hystrix.contrib.javanica.annotation.HystrixProperty;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.EmptyResultDataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping(produces="application/json")
public class ItemController {

    @Autowired
    private ItemService itemService;

    private final Greeting greeting;

    public ItemController(ItemService itemService, Greeting greeting) {
        this.itemService = itemService;
        this.greeting = greeting;
    }

    @GetMapping("/greeting")
    public String greeting() {  // to refresh use curl localhost:53419/actuator/refresh -X POST
        return greeting.getMessage();
    }

    @GetMapping("/items")
    public List<Item> allItems() {
        return itemService.findAllItems();
    }

    @HystrixCommand(fallbackMethod="getDefaultItem", commandProperties={
        @HystrixProperty(
                name="execution.isolation.thread.timeoutInMilliseconds",
                value="500")
    })  // if response is not given in 500ms it returns default values from fallback method
    @GetMapping("/items/{id}")
    public ResponseEntity<Item> itemById(@PathVariable("id") int id) {
        Optional<Item> optItem = itemService.findItemById(id);
        if (optItem.isPresent()) {
            return new ResponseEntity<>(optItem.get(), HttpStatus.OK);
        }
        return new ResponseEntity<>(null, HttpStatus.NOT_FOUND);
    }

    private ResponseEntity<Item> getDefaultItem() {
        Item item = new Item(0, "Default", 0, "Category", new Date());
        return new ResponseEntity<>(item, HttpStatus.OK);
    }

    @PostMapping(path="/items", consumes="application/json")
    @ResponseStatus(HttpStatus.CREATED)
    public Item addItem(@RequestBody Item item) {
        return itemService.saveItem(item);
    }

    @PutMapping(path="/items/{id}", consumes="application/json")
    @ResponseStatus(HttpStatus.OK)
    public Item updateItem(@RequestBody Item item) {
        return itemService.updateItem(item);
    }

    @DeleteMapping("/items/{id}")
    @ResponseStatus(code= HttpStatus.NO_CONTENT)
    public void deleteItem(@PathVariable("id") int id) {
        try {
            itemService.deleteItemById(id);
        } catch (EmptyResultDataAccessException e) {}
    }
}